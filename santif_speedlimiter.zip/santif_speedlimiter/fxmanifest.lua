fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author '@Santif_'
version '1.0.0'
description 'Limitador de velocidade || Speedlimiter'

client_scripts {
	'client/main.lua',
	'client/npc.lua',
}

server_scripts {
	'server/main.lua',
}

shared_scripts {
    'config.lua',
}

escrow_ignore {
	'config.lua',
	'client/main.lua',
	'client/npc.lua',
	'server/main.lua',
}