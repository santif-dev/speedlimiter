# santif_speedlimiter

A speed limiter for all vehicles. You can got to an NPC to remove the limit (this has to be done every restart). You can also whitelist cars to never be limited.

## Installation

> Drag *santif_speedlimiter* into your server's resources folder and add `ensure santif_speedlimiter` to your *server.cfg*.

> Set up the *config.lua* to your liking.

> Check and add your desired event/target in the *client/npc.lua*.

> Restart server.